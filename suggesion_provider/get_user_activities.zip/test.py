import json
import numpy as np
import chromadb
import get_user_activities as gua

chroma_client = chromadb.Client()

collection = chroma_client.create_collection(name="story_embeddings")

# add data to the collection
#
#

def recommend_stories(user_id):
    data = gua.get_user_suggestions(user_id)
    recent_story_embeddings = []

    for story in data:
        record_id = story['story_id']
        record = collection.get(record_id)   
        if record:
            embedding_vector = record['embedding']
            recent_story_embeddings.append(embedding_vector)
        else:
            print(f"Record not found for ID: {record_id}")
    
    if not recent_story_embeddings:
        return []
    
    embeddings_vector_array = np.vstack(recent_story_embeddings)
    average_embedding_vector = np.mean(embeddings_vector_array, axis=0)

    similar_items = collection.search(average_embedding_vector, top_k=5)
    recommended_story_ids = [item['id'] for item in similar_items]
    
    return recommended_story_ids
